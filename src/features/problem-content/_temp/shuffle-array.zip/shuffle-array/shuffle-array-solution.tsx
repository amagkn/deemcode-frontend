import React from "react";

const ShuffleArraySolution: React.FC = () => {
  return <div>Решение задачи шафла</div>;
};

export { ShuffleArraySolution };
