import React from "react";
import { Box } from "@mui/material";
import { PrimaryText } from "../../../../../shared/components/text/PrimaryText";
import { ConstraintText } from "../../../../../shared/components/text/ConstraintText";

const ShuffleArrayDescription: React.FC = () => {
  return (
    <Box sx={{ padding: 5 }}>
      <PrimaryText>
        Напишите функцию <ConstraintText>shuffle(array)</ConstraintText>,
        которая перемешивает (переупорядочивает случайным образом) элементы
        массива. Многократные прогоны через shuffle могут привести к разным
        последовательностям элементов. Например:
      </PrimaryText>
    </Box>
  );
};

export { ShuffleArrayDescription };
